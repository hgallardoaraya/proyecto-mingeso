package com.mingeso.topeducation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TopeducationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TopeducationApplication.class, args);
	}

}
