package com.mingeso.topeducation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TopeducationApplicationTests {

	@Test
	void contextLoads() {
	}

}
